-- Schema hub_reseau
CREATE SCHEMA IF NOT EXISTS hub_reseau;

-- Types
CREATE TYPE hub_reseau.network_link_type AS ENUM ('FIBRE','WAN','OPERATEUR');
CREATE TYPE hub_reseau.network_operator AS ENUM ('LINKT','MOJI','RED','OTHER');
CREATE TYPE hub_reseau.duct_status AS ENUM ('LIBRE','OCCUPE');
CREATE TYPE hub_reseau.access_type AS ENUM ('FIBRE','WAN','ADSL','SDSL','4G');

-- Tables
CREATE TABLE hub_reseau.network_links (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 site_a VARCHAR NOT NULL,
 site_b VARCHAR NOT NULL,
 type hub_reseau.network_link_type NOT NULL,
 capacity VARCHAR,
 operator hub_reseau.network_operator,
 carries_data BOOLEAN DEFAULT TRUE,
 carries_voice BOOLEAN DEFAULT FALSE,
 is_loop BOOLEAN DEFAULT FALSE,
 is_redundant BOOLEAN DEFAULT FALSE,
 geometry GEOMETRY(LINESTRING,4326),
 created_at TIMESTAMP DEFAULT NOW(),
 updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE hub_reseau.network_access (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 site_code VARCHAR NOT NULL,
 type hub_reseau.access_type NOT NULL,
 operator hub_reseau.network_operator,
 mode VARCHAR,
 bandwidth VARCHAR,
 carries_data BOOLEAN DEFAULT TRUE,
 carries_voice BOOLEAN DEFAULT FALSE,
 comment TEXT,
 created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE hub_reseau.ducts (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 name VARCHAR,
 status hub_reseau.duct_status NOT NULL,
 capacity INTEGER,
 used_capacity INTEGER DEFAULT 0,
 geometry GEOMETRY(LINESTRING,4326),
 created_at TIMESTAMP DEFAULT NOW()
);

-- INDEX
CREATE INDEX idx_links_site_a ON hub_reseau.network_links(site_a);
CREATE INDEX idx_links_site_b ON hub_reseau.network_links(site_b);
CREATE INDEX idx_access_site ON hub_reseau.network_access(site_code);
CREATE INDEX idx_links_geom ON hub_reseau.network_links USING GIST (geometry);
CREATE INDEX idx_ducts_geom ON hub_reseau.ducts USING GIST (geometry);
