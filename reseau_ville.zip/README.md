# Réseau Ville - Spécifications

Voir prompt Claude pour instructions principales.

Points clés :
- Utiliser schema hub_reseau
- Ne pas créer table sites
- Utiliser site_code (S001...)
- Vue carte + topologie
