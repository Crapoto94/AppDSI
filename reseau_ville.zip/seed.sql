-- CORE
INSERT INTO hub_reseau.network_links (site_a,site_b,type,capacity,is_loop) VALUES
('S001','S064','FIBRE','40G',true),
('S001','S005','FIBRE','10G',true),
('S005','S004','FIBRE','10G',true),
('S004','S022','FIBRE','10G',true),
('S022','S001C','FIBRE','10G',true),
('S001C','S001','FIBRE','10G',true);

INSERT INTO hub_reseau.network_access (site_code,type,operator,mode,bandwidth) VALUES
('S045','WAN','LINKT','MPLS','30M'),
('S028','ADSL','OTHER','INTERNET','20M');

INSERT INTO hub_reseau.ducts (name,status,capacity,used_capacity) VALUES
('FO_Boucle_Nord','OCCUPE',48,36),
('FO_Boucle_Sud','OCCUPE',48,40),
('FO_Extension','LIBRE',24,0);
